package principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import persistence.StorageBooks;

@RestController
@SpringBootApplication
public class BookApplication {
	public static StorageBooks storageBooks;

	@RequestMapping(value = "/book", method = RequestMethod.GET, produces = "application/json")
	public String getAllBooks() {
		Gson gson = new Gson();
		return gson.toJson(storageBooks.getAllBoooks());
	}

	@RequestMapping(value = "/book/title/{title}", method = RequestMethod.GET, produces = "application/json")
	public String getAllBooksByTitle(@PathVariable("title") String title) {
		Gson gson = new Gson();
		return gson.toJson(storageBooks.getBooksByTitle(title));
	}

	@RequestMapping(value = "/book/author/{author}", method = RequestMethod.GET, produces = "application/json")
	public String getAllBooksByAutor(@PathVariable("author") String autor) {
		Gson gson = new Gson();
		return gson.toJson(storageBooks.getBooksByAutor(autor));
	}

	@RequestMapping(value = "/book/isbn/{isbn}", method = RequestMethod.GET, produces = "application/json")
	public String getAllBooksByISBN(@PathVariable("isbn") String isbn) {
		Gson gson = new Gson();
		return gson.toJson(storageBooks.getBooksByISBN(isbn));
	}

	@RequestMapping(value = "/book/criticism/{isbn}", method = RequestMethod.GET)
	public String getCriticismByISBN(@PathVariable("isbn") String isbn) {
		return storageBooks.getCriticasByISBN(isbn);
	}

	public static void main(String[] args) {
		storageBooks = new StorageBooks();
		SpringApplication.run(BookApplication.class, args);
	}
}
