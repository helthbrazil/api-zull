package entity;

import java.util.List;

public class Livro {
	private String ISBN;
	private String titulo;
	private String descricao;
	private List<String> autores;
	private List<String> palavrasChaves;
	private String critica;
	private Integer anoDePublicacao;
	private Integer edicao;
	private String editoria;
	private String descricaoDoLivro;
	private List<String> livrosRelacionados;

	public Livro() {

	}

	public Livro(String iSBN, String titulo, String descricao, List<String> autores, List<String> palavrasChaves,
			String critica, Integer anoDePublicacao, Integer edicao, String editoria, String descricaoDoLivro,
			List<String> livrosRelacionados) {
		super();
		ISBN = iSBN;
		this.titulo = titulo;
		this.descricao = descricao;
		this.autores = autores;
		this.palavrasChaves = palavrasChaves;
		this.critica = critica;
		this.anoDePublicacao = anoDePublicacao;
		this.edicao = edicao;
		this.editoria = editoria;
		this.descricaoDoLivro = descricaoDoLivro;
		this.livrosRelacionados = livrosRelacionados;
	}

	public List<String> getAutores() {
		return autores;
	}

	public void setAutores(List<String> autores) {
		this.autores = autores;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public List<String> getPalavrasChaves() {
		return palavrasChaves;
	}

	public void setPalavrasChaves(List<String> palavrasChaves) {
		this.palavrasChaves = palavrasChaves;
	}

	public String getCritica() {
		return critica;
	}

	public void setCritica(String critica) {
		this.critica = critica;
	}

	public Integer getAnoDePublicacao() {
		return anoDePublicacao;
	}

	public void setAnoDePublicacao(Integer anoDePublicacao) {
		this.anoDePublicacao = anoDePublicacao;
	}

	public Integer getEdicao() {
		return edicao;
	}

	public void setEdicao(Integer edicao) {
		this.edicao = edicao;
	}

	public String getEditoria() {
		return editoria;
	}

	public void setEditoria(String editoria) {
		this.editoria = editoria;
	}

	public String getDescricaoDoLivro() {
		return descricaoDoLivro;
	}

	public void setDescricaoDoLivro(String descricaoDoLivro) {
		this.descricaoDoLivro = descricaoDoLivro;
	}

	public List<String> getLivrosRelacionados() {
		return livrosRelacionados;
	}

	public void setLivrosRelacionados(List<String> livrosRelacionados) {
		this.livrosRelacionados = livrosRelacionados;
	}

}
