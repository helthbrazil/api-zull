package persistence;

import java.util.ArrayList;
import java.util.List;

import entity.Livro;

public class StorageBooks {
	private List<Livro> livros;

	public StorageBooks() {
		this.livros = new ArrayList<>();
		initStorage();
	}

	public List<Livro> getAllBoooks() {
		return livros;
	}

	private void initStorage() {
		createBook("58943600234", "Cálculo 1", "Livro de Cálculo", new String[] { "João Ricardo" },
				new String[] { "Mátematica", "Cálculo" }, "Muito bom", 1, 2015, "UFMG",
				"Livro para iniciantes em cálculos", new String[] { "Cálculo 2" });

		createBook("48735953532", "Cálculo 2", "Livro de Cálculo", new String[] { "Maria e João Ricardo" },
				new String[] { "Mátematica", "Cálculo" }, "Mais ou menos", 2, 2017, "UFMG",
				"Livro para iniciantes em cálculos", new String[] { "Cálculo 1" });

		createBook("95142023433", "Arquitetura de Softare", "Livro de Arquitetura de Software",
				new String[] { "Hebert Ferreira" }, new String[] { "Arquitetura", "Software" }, "O melhor", 1, 2004,
				"Puc Minas Livros", "Livro para iniciantes em cálculos", new String[] { "Engenharia de Software" });
		/*
		 * createBook("91917950144", "", descricao, autores, palavrasChaves,
		 * critica, edicao, anoDePublicacao, editoria, descricaoDoLivro,
		 * livrosRelacionados); createBook("24223061422", "", descricao,
		 * autores, palavrasChaves, critica, edicao, anoDePublicacao, editoria,
		 * descricaoDoLivro, livrosRelacionados); createBook("59372265612", "",
		 * descricao, autores, palavrasChaves, critica, edicao, anoDePublicacao,
		 * editoria, descricaoDoLivro, livrosRelacionados);
		 * createBook("73580239834", "", descricao, autores, palavrasChaves,
		 * critica, edicao, anoDePublicacao, editoria, descricaoDoLivro,
		 * livrosRelacionados); createBook("66356468553", "", descricao,
		 * autores, palavrasChaves, critica, edicao, anoDePublicacao, editoria,
		 * descricaoDoLivro, livrosRelacionados); createBook("16878781345", "",
		 * descricao, autores, palavrasChaves, critica, edicao, anoDePublicacao,
		 * editoria, descricaoDoLivro, livrosRelacionados);
		 * createBook("47801207367", "", descricao, autores, palavrasChaves,
		 * critica, edicao, anoDePublicacao, editoria, descricaoDoLivro,
		 * livrosRelacionados); createBook("26306733787", "", descricao,
		 * autores, palavrasChaves, critica, edicao, anoDePublicacao, editoria,
		 * descricaoDoLivro, livrosRelacionados);
		 */
	}

	private String removeSpecialCaracters(String word) {
		String formattedWord = word.replaceAll("[ãâàáä]", "a").replaceAll("[êèéë&]", "e").replaceAll("[îìíï]", "i")
				.replaceAll("[õôòóö]", "o").replaceAll("[ûúùü]", "u").replaceAll("[ÃÂÀÁÄ]", "A")
				.replaceAll("[ÊÈÉË]", "E").replaceAll("[ÎÌÍÏ]", "I").replaceAll("[ÕÔÒÓÖ]", "O")
				.replaceAll("[ÛÙÚÜ]", "U").replace('ç', 'c').replace('Ç', 'C').replace('ñ', 'n').replace('Ñ', 'N')
				.replaceAll("[^a-zA-Z]", " ");

		return formattedWord;
	}

	public List<Livro> getBooksByTitle(String key) {
		List<Livro> listaDeLivros = new ArrayList<>();
		for (Livro livro : this.livros) {
			String tituloLivro = removeSpecialCaracters(livro.getTitulo()).toLowerCase();
			String title = removeSpecialCaracters(key).toLowerCase();
			if (tituloLivro.contains(title))
				listaDeLivros.add(livro);
		}

		return listaDeLivros;
	}

	public List<Livro> getBooksByAutor(String key) {
		List<Livro> listaDeLivros = new ArrayList<>();
		for (Livro livro : this.livros) {
			for (String autor : livro.getAutores()) {
				String author = removeSpecialCaracters(autor).toLowerCase();
				String keyFormatted = removeSpecialCaracters(key).toLowerCase();
				if (author.contains(keyFormatted)) {
					listaDeLivros.add(livro);
					break;
				}
			}
		}

		return listaDeLivros;
	}

	public List<Livro> getBooksBykeyWords(String key) {
		List<Livro> listaDeLivros = new ArrayList<>();
		for (Livro livro : this.livros) {
			for (String palavraChave : livro.getPalavrasChaves()) {
				String keyWord = removeSpecialCaracters(palavraChave).toLowerCase();
				String keyFormatted = removeSpecialCaracters(key).toLowerCase();
				if (keyWord.contains(keyFormatted)) {
					listaDeLivros.add(livro);
					break;
				}
			}
		}

		return listaDeLivros;
	}

	public Livro getBooksByISBN(String key) {
		List<Livro> listaDeLivros = new ArrayList<>();
		for (Livro livro : this.livros) {
			if (livro.getISBN().equals(key)) {
				return livro;
			}
		}

		return null;
	}

	public String getCriticasByISBN(String key) {
		String critica = "Livro não encontrado";

		for (Livro livro : this.livros) {
			if (livro.getISBN().equals(key)) {
				return livro.getCritica();
			}
		}

		return critica;
	}

	private void createBook(String ISBN, String titulo, String descricao, String[] autores, String[] palavrasChaves,
			String critica, Integer edicao, Integer anoDePublicacao, String editoria, String descricaoDoLivro,
			String[] livrosRelacionados) {
		List<String> listaDeAutores = new ArrayList<>();
		List<String> listaDePalavrasChaves = new ArrayList<>();
		List<String> listaDeLivrosRelacionados = new ArrayList<>();
		for (String item : livrosRelacionados) {
			listaDeLivrosRelacionados.add(item);
		}

		for (String item : palavrasChaves) {
			listaDePalavrasChaves.add(item);
		}

		for (String item : autores) {
			listaDeAutores.add(item);
		}

		Livro livro = new Livro();
		livro.setISBN(ISBN);
		livro.setTitulo(titulo);
		livro.setDescricao(descricao);
		livro.setAutores(listaDeAutores);
		livro.setPalavrasChaves(listaDePalavrasChaves);
		livro.setCritica(critica);
		livro.setEdicao(edicao);
		livro.setAnoDePublicacao(anoDePublicacao);
		livro.setEditoria(editoria);
		livro.setDescricaoDoLivro(descricaoDoLivro);
		livro.setLivrosRelacionados(listaDeLivrosRelacionados);

		livros.add(livro);
	}
}
